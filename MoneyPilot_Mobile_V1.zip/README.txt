MoneyPilot Mobile V1
用 iPhone Safari 開啟 index.html 所在的公開網址即可使用。
資料使用 localStorage 儲存在裝置本機。
部署方式：將 index.html 上傳到任何靜態網站服務，例如 GitHub Pages、Netlify、Cloudflare Pages。
